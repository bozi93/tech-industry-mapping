# Tech-Industry Mapping 示例

## 示例1：大语言模型（LLM）行业

### 领域特征

```json
{
  "domain": "大语言模型",
  "tech_category": "AI/软件",
  "knowledge_carrier": {
    "论文": 0.9,
    "开源代码": 0.8,
    "专利": 0.2,
    "产品": 0.1
  },
  "talent_flow_pattern": "顶级实验室 → 大厂研究院 → 创业",
  "commercialization_stage": "快速商业化期",
  "value_chain_structure": "平台型"
}
```

### 技术源流

**学术源头**：
- **奠基论文**：
  - "Attention Is All You Need" (Vaswani et al., 2017) - Transformer架构
  - "BERT: Pre-training" (Devlin et al., 2018) - 预训练范式
  - "GPT-3" (Brown et al., 2020) - 大模型Scaling Law

- **核心研究机构**：
  - Google Brain / DeepMind
  - OpenAI
  - Meta AI (FAIR)
  - Stanford NLP Group
  - Berkeley AI Research

- **关键人物**：
  - Ashish Vaswani (Transformer一作) → Essential AI
  - Ilya Sutskever (OpenAI联合创始人) - 师从Geoffrey Hinton
  - Geoffrey Hinton (深度学习教父) - 图灵奖2018

**技术演进**：
- 2017: Transformer架构
- 2018: BERT/GPT-1
- 2019: GPT-2
- 2020: GPT-3 (175B参数)
- 2022: ChatGPT/GPT-4
- 2023: Claude, Gemini, Llama
- 2024: GPT-4o, Claude 3, Llama 3

**开源生态**：
- Meta Llama系列
- EleutherAI GPT-Neo/GPT-J
- MosaicML MPT
- 01.AI Yi
- 阿里通义千问

### 产业生态

**产业链**：

| 层级 | 核心内容 | 主要玩家 |
|------|----------|----------|
| 上游 | 算力芯片、云服务、数据 | NVIDIA, AMD, AWS, Azure, GCP |
| 中游 | 基础模型、开发平台 | OpenAI, Anthropic, Google, 智谱, 月之暗面 |
| 下游 | 应用产品、行业方案 | Jasper, Copy.ai, 各类AI应用 |

**竞争格局**：

| 梯队 | 海外 | 中国 |
|------|------|------|
| 第一梯队 | OpenAI (GPT-4), Google (Gemini) | 百度(文心), 阿里(通义) |
| 第二梯队 | Anthropic (Claude), Meta (Llama) | 智谱, 月之暗面, MiniMax |
| 第三梯队 | Cohere, AI21 | 百川, 零一万物, 讯飞 |

**商业模式**：
- API服务收费（OpenAI, Anthropic）
- 订阅制（ChatGPT Plus, Claude Pro）
- 私有化部署（企业版）
- 云服务集成（Azure OpenAI, AWS Bedrock）

**投资生态**：

| 公司 | 最新轮次 | 累计融资 | 主要投资机构 | 估值 |
|------|----------|----------|--------------|------|
| OpenAI | - | $10B+ | Microsoft, Thrive, a16z | $800亿 |
| Anthropic | D轮 | $7.6B | Google, Amazon, Spark | $184亿 |
| 智谱AI | B+轮 | $3B+ | 阿里, 腾讯, 红杉, 高瓴 | $30亿 |
| 月之暗面 | B轮 | $1B | 红杉中国, 阿里, 小红书 | $25亿 |
| MiniMax | B轮 | $600M+ | 腾讯, 米哈游, 高瓴 | $12亿 |
| 百川智能 | A轮 | $300M+ | 阿里, 腾讯, 红杉 | $12亿 |

**投资人背景影响**：
- **Microsoft投资OpenAI**：Azure云服务整合，企业客户渠道，算力支持
- **Google投资Anthropic**：与Google Cloud深度整合，Gemini竞争中的战略布局
- **阿里投资智谱/月之暗面**：阿里云生态协同，通义千问战略补充
- **红杉/高瓴多家布局**：分散风险，覆盖全赛道

### 技术-产业融合洞察

**关键转化路径**：
1. Transformer论文 (Google, 2017)
   ↓
2. GPT系列发展 (OpenAI)
   ↓
3. ChatGPT产品化 (2022.11)
   ↓
4. 全球大模型创业潮 (2023-2024)

**人才-公司关联**：
- Ilya Sutskever (Hinton学生) → OpenAI联合创始人
- Dario Amodei (OpenAI前VP) → Anthropic联合创始人
- 杨植麟 (CMU, 师从Ruslan Salakhutdinov) → 月之暗面创始人
- 张鹏 (清华, 师从唐杰) → 智谱AI CEO

**技术路线差异**：
- **GPT路线**：Decoder-only, 生成能力强
- **BERT路线**：Encoder-only, 理解能力强
- **混合路线**：Encoder-Decoder, 平衡能力

---

## 示例2：自动驾驶行业

### 领域特征

```json
{
  "domain": "自动驾驶",
  "tech_category": "AI+硬件",
  "knowledge_carrier": {
    "论文": 0.6,
    "开源代码": 0.5,
    "专利": 0.7,
    "产品": 0.3
  },
  "talent_flow_pattern": "学术界 → 大厂 → 创业",
  "commercialization_stage": "商业化初期",
  "value_chain_structure": "垂直整合"
}
```

### 技术源流

**学术源头**：
- **计算机视觉**：
  - ImageNet (李飞飞, 2009)
  - CNN架构 (LeCun, Hinton)
  - ResNet (何恺明, 2015)

- **SLAM/定位**：
  - ORB-SLAM
  - LSD-SLAM
  - VINS-Mono

- **规划决策**：
  - 强化学习
  - 模仿学习
  - 端到端学习

**关键人物**：
- Sebastian Thrun (Stanford) → Google X → Udacity
- Chris Urmson (CMU) → Google X → Aurora
- 楼天城 (清华/CMU) → Google → 百度 → Pony.ai

### 产业生态

**产业链**：

| 层级 | 核心内容 | 主要玩家 |
|------|----------|----------|
| 上游 | 激光雷达、芯片、高精地图 | Velodyne, NVIDIA, Mobileye, 禾赛, 地平线 |
| 中游 | 算法方案、域控制器 | Waymo, Cruise, 百度Apollo, 小马智行 |
| 下游 | 整车集成、出行服务 | Tesla, 通用, 滴滴, Uber |

**技术路线**：

| 路线 | 传感器方案 | 代表公司 |
|------|------------|----------|
| 纯视觉 | 摄像头为主 | Tesla, Mobileye |
| 多传感器融合 | 激光雷达+摄像头 | Waymo, Cruise, 小鹏 |
| V2X | 车路协同 | 百度, 华为 |

**竞争格局**：

| 类型 | 海外 | 中国 |
|------|------|------|
| Robotaxi | Waymo, Cruise, Aurora | 百度Apollo, 小马智行, 文远知行 |
| 乘用车ADAS | Tesla, Mobileye | 华为, 小鹏, 蔚来, 理想 |
| 卡车自动驾驶 | TuSimple, Embark | 图森, 智加, 嬴彻 |

**投资生态**：

| 公司 | 最新轮次 | 累计融资 | 主要投资机构 | 估值/市值 |
|------|----------|----------|--------------|-----------|
| Waymo | - | $5.5B+ | Alphabet | Google子公司 |
| Cruise | - | $10B+ | GM, Honda, Microsoft | GM子公司 |
| Aurora | SPAC | $2B+ | 红杉, Index, T. Rowe | 上市 |
| 小马智行 | D轮 | $1B+ | 丰田, 红杉, IDG | $53亿 |
| 文远知行 | D轮 | $700M+ | 雷诺日产三菱, 小鹏 | $51亿 |
| 图森未来 | IPO | $600M+ | 新浪, 英伟达, 鼎晖 | 上市 |

**投资人背景影响**：
- **车企战投主导**：丰田投小马智行，通用控股Cruise，车企寻求技术整合
- **产业资本布局**：英伟达投图森，寻求芯片场景落地
- **独立发展困难**：Waymo/Cruise依赖母公司输血，独立创业公司融资压力大

---

## 示例3：钙钛矿电池行业

### 领域特征

```json
{
  "domain": "钙钛矿电池",
  "tech_category": "新能源材料",
  "knowledge_carrier": {
    "论文": 0.9,
    "开源代码": 0.1,
    "专利": 0.8,
    "产品": 0.1
  },
  "talent_flow_pattern": "大学PhD → 博士后 → 教授创业",
  "commercialization_stage": "产业化前期",
  "value_chain_structure": "专业化分工"
}
```

### 技术源流

**学术源头**：
- **奠基论文**：
  - "Efficient Hybrid Solar Cells" (Kojima et al., 2009) - 首个钙钛矿太阳能电池
  - "Lead Iodide Perovskite" (Kim et al., 2012) - 固态钙钛矿电池
  - "Certified 22.1% Efficiency" (Yang Yang, UCLA, 2016)

- **核心研究机构**：
  - 牛津大学 (Henry Snaith)
  - UCLA (Yang Yang)
  - EPFL (Michael Grätzel)
  - 中科院大连化物所
  - 华东理工大学

- **关键人物**：
  - Henry Snaith (牛津) - 钙钛矿电池先驱, Oxford PV创始人
  - Michael Grätzel (EPFL) - 染料敏化电池之父
  - Yang Yang (UCLA) - 效率突破
  - 游经碧 (中科院) - 国内领先研究者

**技术演进**：
- 2009: 首个钙钛矿电池 (效率3.8%)
- 2012: 固态钙钛矿电池 (效率10%)
- 2016: 认证效率22.1%
- 2020: 实验室效率25%+
- 2023: 叠层电池效率33%+
- 2024: 商业化量产起步

### 产业生态

**产业链**：

| 层级 | 核心内容 | 主要玩家 |
|------|----------|----------|
| 上游 | 钙钛矿材料、TCO玻璃、封装材料 | 金晶科技, 亚玛顿 |
| 中游 | 电池组件制造 | Oxford PV, 协鑫纳米, 纤纳光电 |
| 下游 | BIPV, 光伏电站 | 建筑集成, 分布式光伏 |

**技术路线**：

| 路线 | 结构 | 优势 | 挑战 |
|------|------|------|------|
| 单结 | 单层钙钛矿 | 工艺简单 | 效率上限低 |
| 叠层 | 钙钛矿+晶硅 | 效率高(30%+) | 工艺复杂 |
| 全钙钛矿叠层 | 宽带+窄带钙钛矿 | 成本低 | 稳定性挑战 |

**竞争格局**：

| 类型 | 海外 | 中国 |
|------|------|------|
| 学术转化 | Oxford PV, Swift Solar | 纤纳光电, 协鑫纳米 |
| 大厂布局 | First Solar, Panasonic | 宁德时代, 隆基绿能 |
| 创业公司 | Saule Technologies | 极电光能, 曜能科技 |

**投资生态**：

| 公司 | 最新轮次 | 累计融资 | 主要投资机构 | 估值 |
|------|----------|----------|--------------|------|
| Oxford PV | C轮 | $150M+ | 牛津大学, 金风科技 | - |
| 纤纳光电 | C轮 | $300M+ | 三峡资本, 京能集团, 招银国际 | - |
| 协鑫纳米 | 战略融资 | $500M+ | 协鑫集团, 苏州国资 | - |
| 极电光能 | Pre-A轮 | $100M+ | 碧桂园创投, 九智资本 | - |

**投资人背景影响**：
- **政府基金主导**：三峡资本、京能集团等能源国企布局，寻求新能源技术储备
- **产业资本协同**：协鑫集团内部孵化，产业链垂直整合
- **房地产跨界**：碧桂园创投布局极电光能，寻求BIPV场景（建筑光伏一体化）
- **融资节奏慢**：技术成熟度低，商业化周期长，融资轮次间隔长

---

## 示例4：人形机器人行业

### 领域特征

```json
{
  "domain": "人形机器人",
  "tech_category": "AI+硬件+控制",
  "knowledge_carrier": {
    "论文": 0.5,
    "开源代码": 0.4,
    "专利": 0.6,
    "产品": 0.4
  },
  "talent_flow_pattern": "学术/大厂 → 创业",
  "commercialization_stage": "早期探索期",
  "value_chain_structure": "垂直整合"
}
```

### 技术源流

**学术源头**：
- **控制理论**：
  - 波士顿动力 (Marc Raibert) - 动态平衡控制
  - MIT CSAIL - 运动规划

- **AI决策**：
  - 强化学习 (Sergey Levine, Berkeley)
  - 模仿学习
  - 大模型+机器人 (Google RT-1/RT-2)

- **核心人物**：
  - Marc Raibert (MIT) → 波士顿动力 → 现代汽车
  - Sergey Levine (Berkeley) - 机器人学习先驱
  - 王兴兴 (上海大学) - 宇树科技创始人

### 产业生态

**产业链**：

| 层级 | 核心内容 | 主要玩家 |
|------|----------|----------|
| 上游 | 执行器、传感器、芯片 | Harmonic Drive, NVIDIA, Intel |
| 中游 | 本体制造、运动控制 | 波士顿动力, Agility, 优必选 |
| 下游 | 工业应用、服务场景 | 工厂, 物流, 家庭服务 |

**竞争格局**：

| 公司 | 背景 | 产品 | 特点 |
|------|------|------|------|
| 波士顿动力 | MIT | Atlas, Spot | 动态能力最强 |
| Tesla | 马斯克 | Optimus | 大规模量产目标 |
| Agility | Oregon State | Digit | 物流场景专注 |
| Figure AI | 创业 | Figure 01 | OpenAI投资 |
| 优必选 | 创业 | Walker | 中国领先 |
| 宇树科技 | 上海大学 | H1, G1 | 高性价比 |
| 智元机器人 | 创业 | 远征A1 | 华为系背景 |

**投资生态**：

| 公司 | 最新轮次 | 累计融资 | 主要投资机构 | 估值 |
|------|----------|----------|--------------|------|
| 波士顿动力 | 收购 | - | 现代汽车 (收购价$1.1B) | 现代子公司 |
| Figure AI | B轮 | $750M+ | OpenAI, 微软, NVIDIA, 贝佐斯 | $26亿 |
| Agility | B轮 | $180M+ | DCVC, Playground Global | - |
| 优必选 | IPO | $500M+ | 腾讯, 启明, 鼎晖 | 上市 |
| 宇树科技 | B轮 | $100M+ | 红杉中国, 顺为, 深创投 | - |
| 智元机器人 | A轮 | $200M+ | 高瓴, 鼎晖, 百度风投 | - |

**投资人背景影响**：
- **OpenAI投资Figure AI**：大模型+机器人结合，寻求具身智能落地
- **NVIDIA投资Figure AI**：芯片场景拓展，机器人计算平台布局
- **现代收购波士顿动力**：车企向机器人延伸，工厂自动化需求
- **大厂战投活跃**：百度风投投智元，寻求AI技术外溢
- **中国VC集中布局**：红杉、高瓴多家下注，赛道热度高

**技术-产业融合洞察**：
- 大模型技术正在重塑机器人决策能力（Figure AI + OpenAI合作）
- 特斯拉汽车技术复用（电池、FSD）
- 人才从自动驾驶流向机器人（相似技术栈）
- 投资热度与自动驾驶早期相似，但商业化路径更长
