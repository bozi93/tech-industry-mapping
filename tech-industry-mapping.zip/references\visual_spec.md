# 技术-产业融合图谱可视化规范

## 1. 整体风格

- **风格**：科技商务融合风
- **背景**：白色
- **布局方向**：从左到右（技术→产业流向）
- **字体**：Microsoft YaHei
- **DPI**：150

## 2. 分层布局

```
┌─────────────────────────────────────────────────────────────┐
│  [学术层] 奠基人/论文/实验室                                   │
│       ↓                                                      │
│  [技术层] 开源项目/关键算法/技术突破                           │
│       ↓                                                      │
│  [商业层] 创业公司/大厂产品/应用                              │
│       ↓                                                      │
│  [产业层] 上游 → 中游 → 下游                                 │
└─────────────────────────────────────────────────────────────┘
```

## 3. 节点设计

### 3.1 节点类型与配色

| 节点类型 | 背景色 | 边框色 | 文字色 | 形状 | 层级 |
|----------|--------|--------|--------|------|------|
| 学术奠基人 | #F3E5F5 | #7B1FA2 | #4A148C | box | 学术层 |
| 研究机构 | #E1BEE7 | #8E24AA | #6A1B9A | box | 学术层 |
| 开源项目 | #E3F2FD | #1976D2 | #0D47A1 | cylinder | 技术层 |
| 技术突破 | #BBDEFB | #1565C0 | #0D47A1 | diamond | 技术层 |
| 创业公司 | #E8F5E9 | #388E3C | #1B5E20 | box3D | 商业层 |
| 大厂产品 | #C8E6C9 | #2E7D32 | #1B5E20 | box | 商业层 |
| 上游供应商 | #FFF3E0 | #F57C00 | #E65100 | box | 产业层 |
| 中游平台 | #FFE0B2 | #EF6C00 | #E65100 | box | 产业层 |
| 下游应用 | #FFCC80 | #E65100 | #BF360C | box | 产业层 |
| 支撑服务 | #F5F5F5 | #616161 | #212121 | box | 产业层 |

### 3.2 节点尺寸

- 标准节点：width=1.5, height=0.6
- 核心节点（奠基人/头部公司）：width=2.0, height=0.8
- 字体大小：11pt（标准），12pt（核心）

### 3.3 节点内容格式

**学术节点**：
```
[人名/机构名]
[核心贡献]
[奖项/地位]
```

**技术节点**：
```
[项目/技术名]
[关键特性]
[Stars/影响力]
```

**商业节点**：
```
[公司/产品名]
[细分领域]
[估值/市占率]
```

**产业节点**：
```
[企业名]
[供应内容]
[市占率/规模]
```

## 4. 边设计

### 4.1 边类型

| 边类型 | 样式 | 颜色 | 含义 |
|--------|------|------|------|
| 师承关系 | 实线+箭头 | #7B1FA2 | 博士导师-学生 |
| 技术演进 | 虚线+箭头 | #1976D2 | 技术迭代、改进 |
| 商业转化 | 粗实线+箭头 | #388E3C | 技术→产品→公司 |
| 产业链关系 | 实线 | #F57C00 | 供应/采购关系 |
| 竞争关系 | 实线 | #D32F2F | 竞争对抗 |
| 合作关系 | 实线 | #1976D2 | 战略合作 |

### 4.2 边权重

- 核心关系：penwidth=3
- 重要关系：penwidth=2
- 一般关系：penwidth=1

## 5. 聚类与子图

### 5.1 技术路线聚类

使用 `subgraph cluster_tech_X` 包围同技术路线的节点：
- 背景色：浅灰色 #FAFAFA
- 边框：虚线 #BDBDBD
- 标签：技术路线名称

### 5.2 产业链聚类

使用 `subgraph cluster_chain_X` 包围同产业链环节：
- 背景色：对应环节色系的最浅色
- 边框：实线

### 5.3 公司群组聚类

使用 `subgraph cluster_company_X` 包围战略群组：
- 背景色：白色
- 边框：点线 #757575

## 6. 时间轴设计

位置：左侧垂直时间轴

```
2015 │
     │  [关键事件]
2017 │
     │  [关键事件]
2020 │
     │  [关键事件]
2023 │
```

- 时间线：垂直实线 #424242
- 年份标记：水平短线 + 年份文本
- 事件节点：圆点 + 事件描述

## 7. 图例设计

位置：右下角

```
┌─────────────────────────────────┐
│ 图例                             │
├─────────────────────────────────┤
│ 学术层                           │
│ ■ 奠基人  ■ 研究机构             │
├─────────────────────────────────┤
│ 技术层                           │
│ ▲ 技术突破  ◎ 开源项目           │
├─────────────────────────────────┤
│ 商业层                           │
│ ■ 创业公司  ■ 大厂产品           │
├─────────────────────────────────┤
│ 产业层                           │
│ ■ 上游  ■ 中游  ■ 下游           │
├─────────────────────────────────┤
│ 关系类型                         │
│ → 师承  ⇢ 技术演进  ⇒ 商业转化   │
│ — 产业链  — 竞争  — 合作         │
└─────────────────────────────────┘
```

## 8. 代码模板

```python
import graphviz

dot = graphviz.Digraph(
    format='svg',
    engine='dot',
    graph_attr={
        'rankdir': 'LR',
        'dpi': '150',
        'fontname': 'Microsoft YaHei',
        'bgcolor': 'white',
        'splines': 'ortho'
    },
    node_attr={
        'fontname': 'Microsoft YaHei',
        'shape': 'box',
        'style': 'filled,rounded',
        'fontsize': '11'
    },
    edge_attr={
        'fontname': 'Microsoft YaHei',
        'fontsize': '10'
    }
)

# 学术层节点
dot.node('founder1', 'Geoffrey Hinton\n深度学习奠基人\n图灵奖2018', 
         fillcolor='#F3E5F5', color='#7B1FA2', fontcolor='#4A148C',
         width='2.0', height='0.8')

# 技术层节点
dot.node('tech1', 'Transformer\n注意力机制\n论文引用10万+',
         fillcolor='#BBDEFB', color='#1565C0', fontcolor='#0D47A1',
         shape='diamond')

# 商业层节点
dot.node('company1', 'OpenAI\n大语言模型\n估值$800亿',
         fillcolor='#E8F5E9', color='#388E3C', fontcolor='#1B5E20',
         shape='box3d', width='2.0', height='0.8')

# 产业层节点
dot.node('upstream1', 'NVIDIA\nAI芯片\n市占率80%',
         fillcolor='#FFF3E0', color='#F57C00', fontcolor='#E65100')

# 边
dot.edge('founder1', 'tech1', color='#7B1FA2', penwidth='2')
dot.edge('tech1', 'company1', color='#388E3C', penwidth='3')
dot.edge('upstream1', 'company1', color='#F57C00', penwidth='2')

# 输出
dot.render('tech_industry_map', cleanup=True)
```

## 9. 布局约束

### 9.1 层级约束

使用 `rank=same` 对齐同层级节点：
```python
with dot.subgraph() as s:
    s.attr(rank='same')
    s.node('company1')
    s.node('company2')
```

### 9.2 顺序约束

使用 `weight` 控制边的重要性：
- 核心关系：weight=10
- 重要关系：weight=5
- 一般关系：weight=1

### 9.3 聚类约束

使用 `cluster` 保持群组内聚：
```python
with dot.subgraph(name='cluster_tech1') as c:
    c.attr(label='Transformer路线', style='dashed', color='#BDBDBD')
    c.node('tech1')
    c.node('tech2')
```
